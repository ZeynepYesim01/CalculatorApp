using System.Data;
using System.Drawing.Drawing2D;
using System.Globalization;
using System.Windows.Forms;

namespace HesapMakinesi3
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        double sayi1 = 0;
        string seciliIslem = "";

        private void IslemButon_Click(object sender, EventArgs e)
        {
            sayi1 = double.Parse(txtText.Text);
            Button btn = (Button)sender;
            seciliIslem = ((Button)sender).Text;
            txtText.Clear();
        }

        private void button8_Click(object sender, EventArgs e)
        {
            string[] par�alar = txtText.Text.Trim().Split(' ');
            if (par�alar.Length > 0)
            {
                txtText.Text = string.Join(" ", par�alar.Take(par�alar.Length - 1));
            }
        }

        private void button9_Click(object sender, EventArgs e)
        {
            if (txtText.Text.Length > 0)
            {
                txtText.Text = txtText.Text.Substring(0, txtText.Text.Length - 1);
            }
        }

        private void button10_Click(object sender, EventArgs e)
        {
            txtText.Text = "";
        }

        private void button11_Click(object sender, EventArgs e)
        {
            double sayi;

            if (double.TryParse(txtText.Text, out sayi))
            {
                if (sayi != 0)
                {
                    double sonuc = 1 / sayi;
                    txtText.Text = sonuc.ToString();
                }
            }
        }

        private void button12_Click(object sender, EventArgs e)
        {
            double sayi;

            if (double.TryParse(txtText.Text, out sayi))
            {
                double sonuc = Math.Pow(sayi, 2);
                txtText.Text = sonuc.ToString();
            }
        }

        private void button13_Click(object sender, EventArgs e)
        {
            double sayi;

            if (double.TryParse(txtText.Text, out sayi))
            {
                if (sayi >= 0)
                {
                    double sonuc = Math.Sqrt(sayi);
                    txtText.Text = sonuc.ToString();
                }
            }
        }
        private void SayisalButon_Click(object sender, EventArgs e)
        {

            Button btn = (Button)sender;
            txtText.Text += btn.Text;
        }

        private void button27_Click(object sender, EventArgs e)
        {
            if (txtText.Text != "")
            {
                double sayi = Convert.ToDouble(txtText.Text);
                sayi = -sayi;
                txtText.Text = sayi.ToString();
            }
        }
        private void Esittir_Click(object sender, EventArgs e)
        {
            EsittirIslemiYap();
        }
        double sayi2;
        double sonuc = 0;
        bool expTusu = false;
        bool modTusu = false;
        string islem;

        private void EsittirIslemiYap()
        {


            if (!double.TryParse(txtText.Text, out sayi2))
                return;

            switch (seciliIslem)
            {
                case "+": sonuc = sayi1 + sayi2; break;
                case "-": sonuc = sayi1 - sayi2; break;
                case "x": sonuc = sayi1 * sayi2; break;
                case "/": sonuc = sayi2 != 0 ? sayi1 / sayi2 : 0; break;
                case "%": sonuc = (sayi1 * sayi2) / 100; break;
                case "Mod": sonuc = sayi1 % sayi2; break;
                case "x^y": sonuc = Math.Pow(sayi1, sayi2); break;
                case "Exp": sonuc = sayi1 * Math.Pow(10, sayi2); break;
                    // Daha fazla i�lem ekleyebilirsin
            }


            if (!double.TryParse(txtText.Text, out sayi2))
                return;



            if (expTusu)
            {
                sonuc = Math.Pow(sayi1, sayi2);
                expTusu = false;
            }
            else if (modTusu)
            {
                sonuc = sayi1 % sayi2;
                modTusu = false;
            }

            switch (islem)
            {
                case "x^y":
                    txtText.Text = Math.Pow(sayi1, sayi2).ToString();
                    break;

                case "+":
                    txtText.Text = (sayi1 + sayi2).ToString();
                    break;


            }
            switch (seciliIslem)
            {
                case "power":
                    sonuc = Math.Pow(sayi1, sayi2);
                    break;

            }

           
            txtText.Text = sonuc.ToString();

          
        }
        private void virgul_Click(object sender, EventArgs e)
        {
            if (!txtText.Text.Contains(","))
            {
                txtText.Text += ",";
            }
        }
        private void ParantezButon_Click(object sender, EventArgs e)
        {
            Button btn = (Button)sender;
            txtText.Text += btn.Text;
        }

        private void button1_Click(object sender, EventArgs e)
        {
            panel1.Visible = !panel1.Visible;
        }

        private void panel1_Paint(object sender, PaintEventArgs e)
        {
            panel1.BringToFront();

        }

        private void button32_Click(object sender, EventArgs e)
        {
            txtText.Text = Math.PI.ToString();
        }

        private void button33_Click(object sender, EventArgs e)
        {
            txtText.Text = Math.E.ToString();
        }

        private void button36_Click(object sender, EventArgs e)
        {
            if (double.TryParse(txtText.Text, out double sayi))
            {
                txtText.Text = Math.Pow(sayi, 2).ToString();
            }
        }

        private void button37_Click(object sender, EventArgs e)
        {
            if (double.TryParse(txtText.Text, out double sayi) && sayi != 0)
            {
                txtText.Text = (1 / sayi).ToString();
            }
        }

        private void button38_Click(object sender, EventArgs e)
        {
            if (double.TryParse(txtText.Text, out double sayi))
            {
                txtText.Text = Math.Abs(sayi).ToString();
            }
        }

        private void button39_Click(object sender, EventArgs e)
        {

            if (double.TryParse(txtText.Text, out sayi1))
            {
                expTusu = true;
                txtText.Clear();
            }
        }

        private void button40_Click(object sender, EventArgs e)
        {
            if (double.TryParse(txtText.Text, out sayi1))
            {
                modTusu = true;
                txtText.Clear();
            }
        }

        private void button41_Click(object sender, EventArgs e)
        {
            if (double.TryParse(txtText.Text, out double sayi))
            {
                txtText.Text = Math.Sqrt(sayi).ToString();
            }
        }

        private void button46_Click(object sender, EventArgs e)
        {
            if (double.TryParse(txtText.Text, out sayi1))
            {
                seciliIslem = "power";
                txtText.Clear();
            }
        }

        private void button51_Click(object sender, EventArgs e)
        {
            if (double.TryParse(txtText.Text, out double sayi))
            {
                txtText.Text = Math.Pow(10, sayi).ToString();
            }
        }
        private void BilimselIslem_Click(object sender, EventArgs e)
        {
            Button tiklanan = (Button)sender;
            double sayi;

            if (double.TryParse(txtText.Text, out sayi))
            {
                switch (tiklanan.Text)
                {
                    case "log":
                        txtText.Text = Math.Log10(sayi).ToString();
                        break;
                    case "ln":
                        txtText.Text = Math.Log(sayi).ToString();
                        break;
                    case "sin":
                        txtText.Text = Math.Sin(sayi).ToString();
                        break;
                    case "cos":
                        txtText.Text = Math.Cos(sayi).ToString();
                        break;
                    case "mod":
                        break;
                }
            }
        }
        private double Faktoriyel(int n)
        {
            double sonuc = 1;
            for (int i = 2; i <= n; i++)
            {
                sonuc *= i;
            }
            return sonuc;
        }
        private void button44_Click(object sender, EventArgs e)
        {
            if (int.TryParse(txtText.Text, out int sayi) && sayi >= 0)
            {
                double sonuc = Faktoriyel(sayi);
                txtText.Text = sonuc.ToString();
            }
        }
        private void TumPanelleriGizle()
        {
            PanelStandart.Visible = false;
            PanelBilimsel.Visible = false;
            PanelProgramlayici.Visible = false;
            PanelGrafik.Visible = false;
            panelTarih.Visible = false;
        }
        private void button2_Click(object sender, EventArgs e)
        {
            TumPanelleriGizle();
            PanelStandart.Visible = true;
            PanelStandart.BringToFront();
        }
        private void button3_Click(object sender, EventArgs e)
        {

            TumPanelleriGizle();
            PanelBilimsel.Visible = true;
            PanelBilimsel.BringToFront();
        }

        private void button4_Click(object sender, EventArgs e)
        {
            TumPanelleriGizle();
            PanelGrafik.Visible = true;
            PanelGrafik.BringToFront();
        }

        private void button5_Click(object sender, EventArgs e)
        {
            TumPanelleriGizle();
            PanelProgramlayici.Visible = true;
            PanelProgramlayici.BringToFront();
        }

        private void button6_Click(object sender, EventArgs e)
        {
            TumPanelleriGizle();
            panelTarih.Visible = true;
            panelTarih.BringToFront();
        }
        double Hesapla(double x, string ifade)
        {
            switch (ifade)
            {
                case "x": return x;
                case "x^2": return x * x;
                case "sin(x)": return Math.Sin(x);
                case "cos(x)": return Math.Cos(x);
                case "tan(x)": return Math.Tan(x);
                case "log(x)": return Math.Log10(x);
                case "ln(x)": return Math.Log(x);
                default: return 0; // ge�ersiz ifade
            }
            try
            {
                // "x" yerine gelen de�eri ifade i�inde de�i�tirelim
                ifade = ifade.Replace("x", x.ToString());

                // �fadeyi DataTable ile hesaplayal�m
                var result = new DataTable().Compute(ifade, null);

                return Convert.ToDouble(result);
            }
            catch
            {
                return 0; // Hatal� durumlar i�in 0 d�ner
            }
        }
        private void PanelGrafik_Paint(object sender, PaintEventArgs e)
        {

            Graphics g = e.Graphics;
            g.SmoothingMode = SmoothingMode.AntiAlias; // �izimlerin p�r�zs�z olmas�n� sa�lar

            int merkezX = PanelGrafik.Width / 2; // Yatay eksen merkezi
            int merkezY = PanelGrafik.Height / 2; // Dikey eksen merkezi
            float �l�ek = 20f; // Grafi�in �l�e�i

            Pen eksenKalem = new Pen(Color.Black, 1); // Eksenleri �izecek kalem
            g.DrawLine(eksenKalem, 0, merkezY, PanelGrafik.Width, merkezY); // X ekseni
            g.DrawLine(eksenKalem, merkezX, 0, merkezX, PanelGrafik.Height); // Y ekseni

            Pen fonksiyonKalem = new Pen(Color.Blue, 2); // Fonksiyonu �izecek kalem
            string ifade = txtText.Text; // Kullan�c�n�n girdi�i fonksiyon ifadesi

            // X de�erini -MerkezX/�l�ek ile +MerkezX/�l�ek aras�nda d�ng�ye al�p fonksiyon de�erlerini hesaplar
            for (float x = -merkezX / �l�ek; x < merkezX / �l�ek; x += 0.1f)
            {
                double y1 = Hesapla(x, ifade); // Fonksiyonun birinci noktas�
                double y2 = Hesapla(x + 0.1f, ifade); // Fonksiyonun ikinci noktas�

                // Fonksiyonun X ve Y de�erlerini ekrana d�n��t�r
                float ekranX1 = merkezX + x * �l�ek;
                float ekranY1 = merkezY - (float)y1 * �l�ek;
                float ekranX2 = merkezX + (x + 0.1f) * �l�ek;
                float ekranY2 = merkezY - (float)y2 * �l�ek;

                // �izim yap�lmas�
                g.DrawLine(fonksiyonKalem, ekranX1, ekranY1, ekranX2, ekranY2);
            }
        }

        private void panelTarih_Paint(object sender, PaintEventArgs e)
        {

            DateTime tarih1 = dateTimePicker1.Value;
            DateTime tarih2 = dateTimePicker2.Value;

            TimeSpan fark = tarih2 - tarih1;

            textBox1.Text = $"{Math.Abs(fark.TotalDays)} g�n";
        }
        private void Form1_Load(object sender, EventArgs e)
        {
            txtText.KeyDown += new KeyEventHandler(txtText_KeyDown);
            comboFormat.Items.Add("Decimal");
            comboFormat.Items.Add("Binary");
            comboFormat.Items.Add("Hexadecimal");
            comboFormat.SelectedIndex = 0; // Varsay�lan Decimal
       
            PanelStandart.Visible = true;
       
        }

        private void buttonEquals_Click(object sender, EventArgs e)
        {
            string expression = txtText.Text;

            try
            {
                var result = new DataTable().Compute(expression, null);
                int intResult = Convert.ToInt32(result);

                // Kullan�c�n�n ComboBox'tan se�ti�i format� al
                string format = comboFormat.SelectedItem.ToString();

                // Format se�imine g�re sonucu g�ster
                if (format == "Binary")
                {
                    txtText.Text = Convert.ToString(intResult, 2); // Binary
                }
                else if (format == "Hexadecimal")
                {
                    txtText.Text = intResult.ToString("X"); // Hex
                }
                else
                {
                    txtText.Text = intResult.ToString(); // Decimal
                }
            }
            catch
            {
                txtText.Text = "HATALI �FADE";
            }
        }
        


        private void EsittirIslemi()
        {
            double sayi2;
            if (double.TryParse(txtText.Text, out sayi2))
            {
                double sonuc = 0;
                switch (seciliIslem)
                {
                    case "+": sonuc = sayi1 + sayi2; break;
                    case "-": sonuc = sayi1 - sayi2; break;
                    case "*": sonuc = sayi1 * sayi2; break;
                    case "/": sonuc = sayi2 != 0 ? sayi1 / sayi2 : 0; break;
                    case "%": sonuc = sayi1 * sayi2 / 100; break;
                    case "x^y": sonuc = Math.Pow(sayi1, sayi2); break;
                }

                txtText.Text = sonuc.ToString();
                string ifade = txtText.Text;

                // Grafik �izimi i�in paneli yenile
                PanelGrafik.Invalidate();  // Burada grafik �izimini tetikliyoruz
            }

        }
        private void txtText_KeyDown(object sender, KeyEventArgs e)
        {

            // E�er kullan�c� Enter tu�una basarsa
            if (e.KeyCode == Keys.Enter)
            {
                e.SuppressKeyPress = true; // Enter tu�unun default i�lemini engeller
                EsittirIslemi(); // E�ittir i�lemini yapar
                PanelGrafik.Invalidate(); // Grafik panelini yeniler
            }
        }

    }
}
