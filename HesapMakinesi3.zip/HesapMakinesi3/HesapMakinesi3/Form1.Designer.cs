﻿namespace HesapMakinesi3
{
    partial class Form1
    {
        /// <summary>
        ///  Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        ///  Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        ///  Required method for Designer support - do not modify
        ///  the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(Form1));
            txtText = new RichTextBox();
            PanelStandart = new TableLayoutPanel();
            button7 = new Button();
            button8 = new Button();
            button9 = new Button();
            button10 = new Button();
            button11 = new Button();
            button12 = new Button();
            button13 = new Button();
            button14 = new Button();
            button15 = new Button();
            button16 = new Button();
            button17 = new Button();
            button18 = new Button();
            button19 = new Button();
            button20 = new Button();
            button21 = new Button();
            button22 = new Button();
            button23 = new Button();
            button24 = new Button();
            button25 = new Button();
            button26 = new Button();
            button27 = new Button();
            button28 = new Button();
            button29 = new Button();
            button30 = new Button();
            PanelProgramlayici = new TableLayoutPanel();
            comboFormat = new ComboBox();
            button31 = new Button();
            button68 = new Button();
            button67 = new Button();
            button66 = new Button();
            button71 = new Button();
            button72 = new Button();
            button70 = new Button();
            button69 = new Button();
            button79 = new Button();
            button80 = new Button();
            button78 = new Button();
            button77 = new Button();
            button75 = new Button();
            button76 = new Button();
            button73 = new Button();
            button74 = new Button();
            button81 = new Button();
            button82 = new Button();
            button86 = new Button();
            button85 = new Button();
            button84 = new Button();
            button83 = new Button();
            button1 = new Button();
            panel1 = new Panel();
            button6 = new Button();
            button5 = new Button();
            button4 = new Button();
            button3 = new Button();
            button2 = new Button();
            PanelBilimsel = new TableLayoutPanel();
            button32 = new Button();
            button33 = new Button();
            button34 = new Button();
            button35 = new Button();
            button36 = new Button();
            button37 = new Button();
            button38 = new Button();
            button39 = new Button();
            button40 = new Button();
            button41 = new Button();
            button42 = new Button();
            button43 = new Button();
            button44 = new Button();
            button45 = new Button();
            button46 = new Button();
            button47 = new Button();
            button48 = new Button();
            button49 = new Button();
            button50 = new Button();
            button51 = new Button();
            button52 = new Button();
            button53 = new Button();
            button54 = new Button();
            button55 = new Button();
            button56 = new Button();
            button57 = new Button();
            button58 = new Button();
            button59 = new Button();
            button60 = new Button();
            button61 = new Button();
            button62 = new Button();
            button63 = new Button();
            button64 = new Button();
            button65 = new Button();
            PanelGrafik = new Panel();
            panelTarih = new Panel();
            textBox1 = new TextBox();
            dateTimePicker2 = new DateTimePicker();
            dateTimePicker1 = new DateTimePicker();
            label3 = new Label();
            label2 = new Label();
            label1 = new Label();
            PanelStandart.SuspendLayout();
            PanelProgramlayici.SuspendLayout();
            panel1.SuspendLayout();
            PanelBilimsel.SuspendLayout();
            panelTarih.SuspendLayout();
            SuspendLayout();
            // 
            // txtText
            // 
            txtText.Location = new Point(7, 60);
            txtText.Name = "txtText";
            txtText.Size = new Size(355, 160);
            txtText.TabIndex = 6;
            txtText.Text = "";
            txtText.KeyDown += txtText_KeyDown;
            // 
            // PanelStandart
            // 
            PanelStandart.ColumnCount = 4;
            PanelStandart.ColumnStyles.Add(new ColumnStyle(SizeType.Percent, 25F));
            PanelStandart.ColumnStyles.Add(new ColumnStyle(SizeType.Percent, 25F));
            PanelStandart.ColumnStyles.Add(new ColumnStyle(SizeType.Percent, 25F));
            PanelStandart.ColumnStyles.Add(new ColumnStyle(SizeType.Percent, 25F));
            PanelStandart.Controls.Add(button7, 0, 0);
            PanelStandart.Controls.Add(button8, 1, 0);
            PanelStandart.Controls.Add(button9, 2, 0);
            PanelStandart.Controls.Add(button10, 3, 0);
            PanelStandart.Controls.Add(button11, 0, 1);
            PanelStandart.Controls.Add(button12, 1, 1);
            PanelStandart.Controls.Add(button13, 2, 1);
            PanelStandart.Controls.Add(button14, 3, 1);
            PanelStandart.Controls.Add(button15, 0, 2);
            PanelStandart.Controls.Add(button16, 1, 2);
            PanelStandart.Controls.Add(button17, 2, 2);
            PanelStandart.Controls.Add(button18, 3, 2);
            PanelStandart.Controls.Add(button19, 0, 3);
            PanelStandart.Controls.Add(button20, 1, 3);
            PanelStandart.Controls.Add(button21, 2, 3);
            PanelStandart.Controls.Add(button22, 3, 3);
            PanelStandart.Controls.Add(button23, 0, 4);
            PanelStandart.Controls.Add(button24, 1, 4);
            PanelStandart.Controls.Add(button25, 2, 4);
            PanelStandart.Controls.Add(button26, 3, 4);
            PanelStandart.Controls.Add(button27, 0, 5);
            PanelStandart.Controls.Add(button28, 1, 5);
            PanelStandart.Controls.Add(button29, 2, 5);
            PanelStandart.Controls.Add(button30, 3, 5);
            PanelStandart.Location = new Point(7, 265);
            PanelStandart.Name = "PanelStandart";
            PanelStandart.RowCount = 6;
            PanelStandart.RowStyles.Add(new RowStyle(SizeType.Percent, 16.666666F));
            PanelStandart.RowStyles.Add(new RowStyle(SizeType.Percent, 16.666666F));
            PanelStandart.RowStyles.Add(new RowStyle(SizeType.Percent, 16.666666F));
            PanelStandart.RowStyles.Add(new RowStyle(SizeType.Percent, 16.666666F));
            PanelStandart.RowStyles.Add(new RowStyle(SizeType.Percent, 16.666666F));
            PanelStandart.RowStyles.Add(new RowStyle(SizeType.Percent, 16.666666F));
            PanelStandart.RowStyles.Add(new RowStyle(SizeType.Absolute, 20F));
            PanelStandart.Size = new Size(355, 246);
            PanelStandart.TabIndex = 7;
            // 
            // button7
            // 
            button7.Location = new Point(3, 3);
            button7.Name = "button7";
            button7.Size = new Size(82, 35);
            button7.TabIndex = 0;
            button7.Text = "%";
            button7.UseVisualStyleBackColor = true;
            button7.Click += IslemButon_Click;
            // 
            // button8
            // 
            button8.Location = new Point(91, 3);
            button8.Name = "button8";
            button8.Size = new Size(82, 35);
            button8.TabIndex = 1;
            button8.Text = "CE";
            button8.UseVisualStyleBackColor = true;
            button8.Click += button8_Click;
            // 
            // button9
            // 
            button9.Location = new Point(179, 3);
            button9.Name = "button9";
            button9.Size = new Size(82, 35);
            button9.TabIndex = 2;
            button9.Text = "C";
            button9.UseVisualStyleBackColor = true;
            button9.Click += button9_Click;
            // 
            // button10
            // 
            button10.Location = new Point(267, 3);
            button10.Name = "button10";
            button10.Size = new Size(85, 35);
            button10.TabIndex = 3;
            button10.Text = "AC";
            button10.UseVisualStyleBackColor = true;
            button10.Click += button10_Click;
            // 
            // button11
            // 
            button11.Location = new Point(3, 44);
            button11.Name = "button11";
            button11.Size = new Size(82, 35);
            button11.TabIndex = 4;
            button11.Text = "1/x";
            button11.UseVisualStyleBackColor = true;
            button11.Click += button11_Click;
            // 
            // button12
            // 
            button12.Location = new Point(91, 44);
            button12.Name = "button12";
            button12.Size = new Size(82, 35);
            button12.TabIndex = 5;
            button12.Text = "x²";
            button12.UseVisualStyleBackColor = true;
            button12.Click += button12_Click;
            // 
            // button13
            // 
            button13.Location = new Point(179, 44);
            button13.Name = "button13";
            button13.Size = new Size(82, 35);
            button13.TabIndex = 6;
            button13.Text = "√x";
            button13.UseVisualStyleBackColor = true;
            button13.Click += button13_Click;
            // 
            // button14
            // 
            button14.Location = new Point(267, 44);
            button14.Name = "button14";
            button14.Size = new Size(85, 35);
            button14.TabIndex = 7;
            button14.Text = "/";
            button14.UseVisualStyleBackColor = true;
            button14.Click += IslemButon_Click;
            // 
            // button15
            // 
            button15.Location = new Point(3, 85);
            button15.Name = "button15";
            button15.Size = new Size(82, 35);
            button15.TabIndex = 8;
            button15.Text = "7";
            button15.UseVisualStyleBackColor = true;
            button15.Click += SayisalButon_Click;
            // 
            // button16
            // 
            button16.Location = new Point(91, 85);
            button16.Name = "button16";
            button16.Size = new Size(82, 35);
            button16.TabIndex = 9;
            button16.Text = "8";
            button16.UseVisualStyleBackColor = true;
            button16.Click += SayisalButon_Click;
            // 
            // button17
            // 
            button17.Location = new Point(179, 85);
            button17.Name = "button17";
            button17.Size = new Size(82, 35);
            button17.TabIndex = 10;
            button17.Text = "9";
            button17.UseVisualStyleBackColor = true;
            button17.Click += SayisalButon_Click;
            // 
            // button18
            // 
            button18.Location = new Point(267, 85);
            button18.Name = "button18";
            button18.Size = new Size(85, 35);
            button18.TabIndex = 11;
            button18.Text = "x";
            button18.UseVisualStyleBackColor = true;
            button18.Click += IslemButon_Click;
            // 
            // button19
            // 
            button19.Location = new Point(3, 126);
            button19.Name = "button19";
            button19.Size = new Size(82, 35);
            button19.TabIndex = 12;
            button19.Text = "4";
            button19.UseVisualStyleBackColor = true;
            button19.Click += SayisalButon_Click;
            // 
            // button20
            // 
            button20.Location = new Point(91, 126);
            button20.Name = "button20";
            button20.Size = new Size(82, 35);
            button20.TabIndex = 13;
            button20.Text = "5";
            button20.UseVisualStyleBackColor = true;
            button20.Click += SayisalButon_Click;
            // 
            // button21
            // 
            button21.Location = new Point(179, 126);
            button21.Name = "button21";
            button21.Size = new Size(82, 35);
            button21.TabIndex = 14;
            button21.Text = "6";
            button21.UseVisualStyleBackColor = true;
            button21.Click += SayisalButon_Click;
            // 
            // button22
            // 
            button22.Location = new Point(267, 126);
            button22.Name = "button22";
            button22.Size = new Size(85, 35);
            button22.TabIndex = 15;
            button22.Text = "-";
            button22.UseVisualStyleBackColor = true;
            button22.Click += IslemButon_Click;
            // 
            // button23
            // 
            button23.Location = new Point(3, 167);
            button23.Name = "button23";
            button23.Size = new Size(82, 35);
            button23.TabIndex = 16;
            button23.Text = "1";
            button23.UseVisualStyleBackColor = true;
            button23.Click += SayisalButon_Click;
            // 
            // button24
            // 
            button24.Location = new Point(91, 167);
            button24.Name = "button24";
            button24.Size = new Size(82, 35);
            button24.TabIndex = 17;
            button24.Text = "2";
            button24.UseVisualStyleBackColor = true;
            button24.Click += SayisalButon_Click;
            // 
            // button25
            // 
            button25.Location = new Point(179, 167);
            button25.Name = "button25";
            button25.Size = new Size(82, 35);
            button25.TabIndex = 18;
            button25.Text = "3";
            button25.UseVisualStyleBackColor = true;
            button25.Click += SayisalButon_Click;
            // 
            // button26
            // 
            button26.Location = new Point(267, 167);
            button26.Name = "button26";
            button26.Size = new Size(85, 35);
            button26.TabIndex = 19;
            button26.Text = "+";
            button26.UseVisualStyleBackColor = true;
            button26.Click += IslemButon_Click;
            // 
            // button27
            // 
            button27.Location = new Point(3, 208);
            button27.Name = "button27";
            button27.Size = new Size(82, 35);
            button27.TabIndex = 20;
            button27.Text = "+/-";
            button27.UseVisualStyleBackColor = true;
            button27.Click += button27_Click;
            // 
            // button28
            // 
            button28.Location = new Point(91, 208);
            button28.Name = "button28";
            button28.Size = new Size(82, 35);
            button28.TabIndex = 21;
            button28.Text = "0";
            button28.UseVisualStyleBackColor = true;
            button28.Click += SayisalButon_Click;
            // 
            // button29
            // 
            button29.Location = new Point(179, 208);
            button29.Name = "button29";
            button29.Size = new Size(82, 35);
            button29.TabIndex = 22;
            button29.Text = ",";
            button29.UseVisualStyleBackColor = true;
            button29.Click += virgul_Click;
            // 
            // button30
            // 
            button30.BackColor = Color.RoyalBlue;
            button30.Font = new Font("Segoe UI", 14.25F);
            button30.ForeColor = SystemColors.Window;
            button30.Location = new Point(267, 208);
            button30.Name = "button30";
            button30.Size = new Size(85, 35);
            button30.TabIndex = 23;
            button30.Text = "=";
            button30.UseVisualStyleBackColor = false;
            button30.Click += Esittir_Click;
            // 
            // PanelProgramlayici
            // 
            PanelProgramlayici.ColumnCount = 4;
            PanelProgramlayici.ColumnStyles.Add(new ColumnStyle(SizeType.Percent, 25F));
            PanelProgramlayici.ColumnStyles.Add(new ColumnStyle(SizeType.Percent, 25F));
            PanelProgramlayici.ColumnStyles.Add(new ColumnStyle(SizeType.Percent, 25F));
            PanelProgramlayici.ColumnStyles.Add(new ColumnStyle(SizeType.Percent, 25F));
            PanelProgramlayici.Controls.Add(comboFormat, 0, 0);
            PanelProgramlayici.Controls.Add(button31, 2, 0);
            PanelProgramlayici.Controls.Add(button68, 1, 1);
            PanelProgramlayici.Controls.Add(button67, 0, 1);
            PanelProgramlayici.Controls.Add(button66, 3, 0);
            PanelProgramlayici.Controls.Add(button71, 0, 2);
            PanelProgramlayici.Controls.Add(button72, 1, 2);
            PanelProgramlayici.Controls.Add(button70, 3, 1);
            PanelProgramlayici.Controls.Add(button69, 2, 1);
            PanelProgramlayici.Controls.Add(button79, 0, 4);
            PanelProgramlayici.Controls.Add(button80, 1, 4);
            PanelProgramlayici.Controls.Add(button78, 3, 3);
            PanelProgramlayici.Controls.Add(button77, 2, 3);
            PanelProgramlayici.Controls.Add(button75, 0, 3);
            PanelProgramlayici.Controls.Add(button76, 1, 3);
            PanelProgramlayici.Controls.Add(button73, 2, 2);
            PanelProgramlayici.Controls.Add(button74, 3, 2);
            PanelProgramlayici.Controls.Add(button81, 2, 4);
            PanelProgramlayici.Controls.Add(button82, 3, 4);
            PanelProgramlayici.Controls.Add(button86, 3, 5);
            PanelProgramlayici.Controls.Add(button85, 2, 5);
            PanelProgramlayici.Controls.Add(button84, 1, 5);
            PanelProgramlayici.Controls.Add(button83, 0, 5);
            PanelProgramlayici.Location = new Point(4, 261);
            PanelProgramlayici.Name = "PanelProgramlayici";
            PanelProgramlayici.RowCount = 6;
            PanelProgramlayici.RowStyles.Add(new RowStyle(SizeType.Percent, 16.6666641F));
            PanelProgramlayici.RowStyles.Add(new RowStyle(SizeType.Percent, 16.6666641F));
            PanelProgramlayici.RowStyles.Add(new RowStyle(SizeType.Percent, 16.6666641F));
            PanelProgramlayici.RowStyles.Add(new RowStyle(SizeType.Percent, 16.6666641F));
            PanelProgramlayici.RowStyles.Add(new RowStyle(SizeType.Percent, 16.6666641F));
            PanelProgramlayici.RowStyles.Add(new RowStyle(SizeType.Percent, 16.6666641F));
            PanelProgramlayici.Size = new Size(355, 247);
            PanelProgramlayici.TabIndex = 9;
            PanelProgramlayici.Visible = false;
            // 
            // comboFormat
            // 
            comboFormat.FormattingEnabled = true;
            comboFormat.Items.AddRange(new object[] { "Decimal", "Binary", "Hexadecimal" });
            comboFormat.Location = new Point(3, 3);
            comboFormat.Name = "comboFormat";
            comboFormat.Size = new Size(82, 23);
            comboFormat.TabIndex = 36;
            // 
            // button31
            // 
            button31.Location = new Point(179, 3);
            button31.Name = "button31";
            button31.Size = new Size(82, 35);
            button31.TabIndex = 0;
            button31.Text = "C";
            button31.UseVisualStyleBackColor = true;
            button31.Click += button9_Click;
            // 
            // button68
            // 
            button68.Location = new Point(91, 44);
            button68.Name = "button68";
            button68.Size = new Size(82, 35);
            button68.TabIndex = 3;
            button68.Text = ")";
            button68.UseVisualStyleBackColor = true;
            button68.Click += ParantezButon_Click;
            // 
            // button67
            // 
            button67.Location = new Point(3, 44);
            button67.Name = "button67";
            button67.Size = new Size(82, 35);
            button67.TabIndex = 2;
            button67.Text = "(";
            button67.UseVisualStyleBackColor = true;
            button67.Click += ParantezButon_Click;
            // 
            // button66
            // 
            button66.Location = new Point(267, 3);
            button66.Name = "button66";
            button66.Size = new Size(85, 35);
            button66.TabIndex = 1;
            button66.Text = "AC";
            button66.UseVisualStyleBackColor = true;
            button66.Click += button10_Click;
            // 
            // button71
            // 
            button71.Location = new Point(3, 85);
            button71.Name = "button71";
            button71.Size = new Size(82, 35);
            button71.TabIndex = 6;
            button71.Text = "7";
            button71.UseVisualStyleBackColor = true;
            button71.Click += SayisalButon_Click;
            // 
            // button72
            // 
            button72.Location = new Point(91, 85);
            button72.Name = "button72";
            button72.Size = new Size(82, 35);
            button72.TabIndex = 7;
            button72.Text = "8";
            button72.UseVisualStyleBackColor = true;
            button72.Click += SayisalButon_Click;
            // 
            // button70
            // 
            button70.Location = new Point(267, 44);
            button70.Name = "button70";
            button70.Size = new Size(85, 35);
            button70.TabIndex = 5;
            button70.Text = "/";
            button70.UseVisualStyleBackColor = true;
            button70.Click += IslemButon_Click;
            // 
            // button69
            // 
            button69.Location = new Point(179, 44);
            button69.Name = "button69";
            button69.Size = new Size(82, 35);
            button69.TabIndex = 4;
            button69.Text = "%";
            button69.UseVisualStyleBackColor = true;
            button69.Click += IslemButon_Click;
            // 
            // button79
            // 
            button79.Location = new Point(3, 167);
            button79.Name = "button79";
            button79.Size = new Size(82, 35);
            button79.TabIndex = 14;
            button79.Text = "1";
            button79.UseVisualStyleBackColor = true;
            button79.Click += SayisalButon_Click;
            // 
            // button80
            // 
            button80.Location = new Point(91, 167);
            button80.Name = "button80";
            button80.Size = new Size(82, 35);
            button80.TabIndex = 15;
            button80.Text = "2";
            button80.UseVisualStyleBackColor = true;
            button80.Click += SayisalButon_Click;
            // 
            // button78
            // 
            button78.Location = new Point(267, 126);
            button78.Name = "button78";
            button78.Size = new Size(85, 35);
            button78.TabIndex = 13;
            button78.Text = "-";
            button78.UseVisualStyleBackColor = true;
            button78.Click += IslemButon_Click;
            // 
            // button77
            // 
            button77.Location = new Point(179, 126);
            button77.Name = "button77";
            button77.Size = new Size(82, 35);
            button77.TabIndex = 12;
            button77.Text = "6";
            button77.UseVisualStyleBackColor = true;
            button77.Click += SayisalButon_Click;
            // 
            // button75
            // 
            button75.Location = new Point(3, 126);
            button75.Name = "button75";
            button75.Size = new Size(82, 35);
            button75.TabIndex = 10;
            button75.Text = "4";
            button75.UseVisualStyleBackColor = true;
            button75.Click += SayisalButon_Click;
            // 
            // button76
            // 
            button76.Location = new Point(91, 126);
            button76.Name = "button76";
            button76.Size = new Size(82, 35);
            button76.TabIndex = 11;
            button76.Text = "5";
            button76.UseVisualStyleBackColor = true;
            button76.Click += SayisalButon_Click;
            // 
            // button73
            // 
            button73.Location = new Point(179, 85);
            button73.Name = "button73";
            button73.Size = new Size(82, 35);
            button73.TabIndex = 8;
            button73.Text = "9";
            button73.UseVisualStyleBackColor = true;
            button73.Click += SayisalButon_Click;
            // 
            // button74
            // 
            button74.Location = new Point(267, 85);
            button74.Name = "button74";
            button74.Size = new Size(85, 35);
            button74.TabIndex = 9;
            button74.Text = "x";
            button74.UseVisualStyleBackColor = true;
            button74.Click += IslemButon_Click;
            // 
            // button81
            // 
            button81.Location = new Point(179, 167);
            button81.Name = "button81";
            button81.Size = new Size(82, 35);
            button81.TabIndex = 16;
            button81.Text = "3";
            button81.UseVisualStyleBackColor = true;
            button81.Click += SayisalButon_Click;
            // 
            // button82
            // 
            button82.Location = new Point(267, 167);
            button82.Name = "button82";
            button82.Size = new Size(85, 35);
            button82.TabIndex = 17;
            button82.Text = "+";
            button82.UseVisualStyleBackColor = true;
            button82.Click += IslemButon_Click;
            // 
            // button86
            // 
            button86.BackColor = Color.RoyalBlue;
            button86.Font = new Font("Segoe UI", 14.25F, FontStyle.Bold, GraphicsUnit.Point, 162);
            button86.ForeColor = SystemColors.Window;
            button86.Location = new Point(267, 208);
            button86.Name = "button86";
            button86.Size = new Size(85, 35);
            button86.TabIndex = 21;
            button86.Text = "=";
            button86.UseVisualStyleBackColor = false;
            button86.Click += buttonEquals_Click;
            // 
            // button85
            // 
            button85.Location = new Point(179, 208);
            button85.Name = "button85";
            button85.Size = new Size(82, 35);
            button85.TabIndex = 20;
            button85.Text = ",";
            button85.UseVisualStyleBackColor = true;
            button85.Click += virgul_Click;
            // 
            // button84
            // 
            button84.Location = new Point(91, 208);
            button84.Name = "button84";
            button84.Size = new Size(82, 35);
            button84.TabIndex = 19;
            button84.Text = "0";
            button84.UseVisualStyleBackColor = true;
            button84.Click += SayisalButon_Click;
            // 
            // button83
            // 
            button83.Location = new Point(3, 208);
            button83.Name = "button83";
            button83.Size = new Size(82, 35);
            button83.TabIndex = 18;
            button83.Text = "+/-";
            button83.UseVisualStyleBackColor = true;
            button83.Click += button27_Click;
            // 
            // button1
            // 
            button1.Font = new Font("Segoe UI", 14.25F, FontStyle.Bold, GraphicsUnit.Point, 162);
            button1.Location = new Point(4, 12);
            button1.Name = "button1";
            button1.Size = new Size(53, 40);
            button1.TabIndex = 10;
            button1.Text = "☰";
            button1.UseVisualStyleBackColor = true;
            button1.Click += button1_Click;
            // 
            // panel1
            // 
            panel1.Controls.Add(button6);
            panel1.Controls.Add(button5);
            panel1.Controls.Add(button4);
            panel1.Controls.Add(button3);
            panel1.Controls.Add(button2);
            panel1.Location = new Point(4, 60);
            panel1.Name = "panel1";
            panel1.Size = new Size(151, 202);
            panel1.TabIndex = 32;
            panel1.Visible = false;
            panel1.Paint += panel1_Paint;
            // 
            // button6
            // 
            button6.Location = new Point(0, 159);
            button6.Name = "button6";
            button6.Size = new Size(129, 33);
            button6.TabIndex = 4;
            button6.Text = "Tarih Hesaplama";
            button6.UseVisualStyleBackColor = true;
            button6.Click += button6_Click;
            // 
            // button5
            // 
            button5.Location = new Point(0, 120);
            button5.Name = "button5";
            button5.Size = new Size(129, 33);
            button5.TabIndex = 3;
            button5.Text = "Programlayıcı";
            button5.UseVisualStyleBackColor = true;
            button5.Click += button5_Click;
            // 
            // button4
            // 
            button4.Location = new Point(0, 81);
            button4.Name = "button4";
            button4.Size = new Size(129, 33);
            button4.TabIndex = 2;
            button4.Text = "Grafik Oluşturma";
            button4.UseVisualStyleBackColor = true;
            button4.Click += button4_Click;
            // 
            // button3
            // 
            button3.Location = new Point(0, 42);
            button3.Name = "button3";
            button3.Size = new Size(129, 33);
            button3.TabIndex = 1;
            button3.Text = "Bilimsel";
            button3.UseVisualStyleBackColor = true;
            button3.Click += button3_Click;
            // 
            // button2
            // 
            button2.Location = new Point(0, 3);
            button2.Name = "button2";
            button2.Size = new Size(129, 33);
            button2.TabIndex = 0;
            button2.Text = "Standart";
            button2.UseVisualStyleBackColor = true;
            button2.Click += button2_Click;
            // 
            // PanelBilimsel
            // 
            PanelBilimsel.ColumnCount = 5;
            PanelBilimsel.ColumnStyles.Add(new ColumnStyle(SizeType.Percent, 20F));
            PanelBilimsel.ColumnStyles.Add(new ColumnStyle(SizeType.Percent, 20F));
            PanelBilimsel.ColumnStyles.Add(new ColumnStyle(SizeType.Percent, 20F));
            PanelBilimsel.ColumnStyles.Add(new ColumnStyle(SizeType.Percent, 20F));
            PanelBilimsel.ColumnStyles.Add(new ColumnStyle(SizeType.Percent, 20F));
            PanelBilimsel.Controls.Add(button32, 1, 0);
            PanelBilimsel.Controls.Add(button33, 2, 0);
            PanelBilimsel.Controls.Add(button34, 3, 0);
            PanelBilimsel.Controls.Add(button35, 4, 0);
            PanelBilimsel.Controls.Add(button36, 0, 1);
            PanelBilimsel.Controls.Add(button37, 1, 1);
            PanelBilimsel.Controls.Add(button38, 2, 1);
            PanelBilimsel.Controls.Add(button39, 3, 1);
            PanelBilimsel.Controls.Add(button40, 4, 1);
            PanelBilimsel.Controls.Add(button41, 0, 2);
            PanelBilimsel.Controls.Add(button42, 1, 2);
            PanelBilimsel.Controls.Add(button43, 2, 2);
            PanelBilimsel.Controls.Add(button44, 3, 2);
            PanelBilimsel.Controls.Add(button45, 4, 2);
            PanelBilimsel.Controls.Add(button46, 0, 3);
            PanelBilimsel.Controls.Add(button47, 1, 3);
            PanelBilimsel.Controls.Add(button48, 2, 3);
            PanelBilimsel.Controls.Add(button49, 3, 3);
            PanelBilimsel.Controls.Add(button50, 4, 3);
            PanelBilimsel.Controls.Add(button51, 0, 4);
            PanelBilimsel.Controls.Add(button52, 1, 4);
            PanelBilimsel.Controls.Add(button53, 2, 4);
            PanelBilimsel.Controls.Add(button54, 3, 4);
            PanelBilimsel.Controls.Add(button55, 4, 4);
            PanelBilimsel.Controls.Add(button56, 0, 5);
            PanelBilimsel.Controls.Add(button57, 1, 5);
            PanelBilimsel.Controls.Add(button58, 2, 5);
            PanelBilimsel.Controls.Add(button59, 3, 5);
            PanelBilimsel.Controls.Add(button60, 0, 6);
            PanelBilimsel.Controls.Add(button61, 1, 6);
            PanelBilimsel.Controls.Add(button62, 2, 6);
            PanelBilimsel.Controls.Add(button63, 3, 6);
            PanelBilimsel.Controls.Add(button64, 4, 6);
            PanelBilimsel.Controls.Add(button65, 4, 5);
            PanelBilimsel.Location = new Point(4, 265);
            PanelBilimsel.Name = "PanelBilimsel";
            PanelBilimsel.RowCount = 7;
            PanelBilimsel.RowStyles.Add(new RowStyle(SizeType.Percent, 14.2857141F));
            PanelBilimsel.RowStyles.Add(new RowStyle(SizeType.Percent, 14.2857141F));
            PanelBilimsel.RowStyles.Add(new RowStyle(SizeType.Percent, 14.2857141F));
            PanelBilimsel.RowStyles.Add(new RowStyle(SizeType.Percent, 14.2857141F));
            PanelBilimsel.RowStyles.Add(new RowStyle(SizeType.Percent, 14.2857141F));
            PanelBilimsel.RowStyles.Add(new RowStyle(SizeType.Percent, 14.2857141F));
            PanelBilimsel.RowStyles.Add(new RowStyle(SizeType.Percent, 14.2857141F));
            PanelBilimsel.Size = new Size(356, 243);
            PanelBilimsel.TabIndex = 33;
            PanelBilimsel.Visible = false;
            // 
            // button32
            // 
            button32.Location = new Point(74, 3);
            button32.Name = "button32";
            button32.Size = new Size(65, 28);
            button32.TabIndex = 1;
            button32.Text = "π";
            button32.UseVisualStyleBackColor = true;
            button32.Click += button32_Click;
            // 
            // button33
            // 
            button33.Location = new Point(145, 3);
            button33.Name = "button33";
            button33.Size = new Size(65, 28);
            button33.TabIndex = 2;
            button33.Text = "e";
            button33.UseVisualStyleBackColor = true;
            button33.Click += button33_Click;
            // 
            // button34
            // 
            button34.Location = new Point(216, 3);
            button34.Name = "button34";
            button34.Size = new Size(65, 28);
            button34.TabIndex = 3;
            button34.Text = "C";
            button34.UseVisualStyleBackColor = true;
            button34.Click += button9_Click;
            // 
            // button35
            // 
            button35.Location = new Point(287, 3);
            button35.Name = "button35";
            button35.Size = new Size(65, 28);
            button35.TabIndex = 4;
            button35.Text = "AC";
            button35.UseVisualStyleBackColor = true;
            button35.Click += button10_Click;
            // 
            // button36
            // 
            button36.Location = new Point(3, 37);
            button36.Name = "button36";
            button36.Size = new Size(65, 28);
            button36.TabIndex = 5;
            button36.Text = "x²";
            button36.UseVisualStyleBackColor = true;
            button36.Click += button36_Click;
            // 
            // button37
            // 
            button37.Location = new Point(74, 37);
            button37.Name = "button37";
            button37.Size = new Size(65, 28);
            button37.TabIndex = 6;
            button37.Text = "1/x";
            button37.UseVisualStyleBackColor = true;
            button37.Click += button37_Click;
            // 
            // button38
            // 
            button38.Location = new Point(145, 37);
            button38.Name = "button38";
            button38.Size = new Size(65, 28);
            button38.TabIndex = 7;
            button38.Text = "|x|";
            button38.UseVisualStyleBackColor = true;
            button38.Click += button38_Click;
            // 
            // button39
            // 
            button39.Location = new Point(216, 37);
            button39.Name = "button39";
            button39.Size = new Size(65, 28);
            button39.TabIndex = 8;
            button39.Text = "exp";
            button39.UseVisualStyleBackColor = true;
            button39.Click += button39_Click;
            // 
            // button40
            // 
            button40.Location = new Point(287, 37);
            button40.Name = "button40";
            button40.Size = new Size(65, 28);
            button40.TabIndex = 9;
            button40.Text = "mod";
            button40.UseVisualStyleBackColor = true;
            button40.Click += button40_Click;
            // 
            // button41
            // 
            button41.Location = new Point(3, 71);
            button41.Name = "button41";
            button41.Size = new Size(65, 28);
            button41.TabIndex = 10;
            button41.Text = "√x";
            button41.UseVisualStyleBackColor = true;
            button41.Click += button41_Click;
            // 
            // button42
            // 
            button42.Location = new Point(74, 71);
            button42.Name = "button42";
            button42.Size = new Size(65, 28);
            button42.TabIndex = 11;
            button42.Text = "(";
            button42.UseVisualStyleBackColor = true;
            button42.Click += ParantezButon_Click;
            // 
            // button43
            // 
            button43.Location = new Point(145, 71);
            button43.Name = "button43";
            button43.Size = new Size(65, 28);
            button43.TabIndex = 12;
            button43.Text = ")";
            button43.UseVisualStyleBackColor = true;
            button43.Click += ParantezButon_Click;
            // 
            // button44
            // 
            button44.Location = new Point(216, 71);
            button44.Name = "button44";
            button44.Size = new Size(65, 28);
            button44.TabIndex = 13;
            button44.Text = "n!";
            button44.UseVisualStyleBackColor = true;
            button44.Click += button44_Click;
            // 
            // button45
            // 
            button45.Location = new Point(287, 71);
            button45.Name = "button45";
            button45.Size = new Size(65, 28);
            button45.TabIndex = 14;
            button45.Text = "/";
            button45.UseVisualStyleBackColor = true;
            button45.Click += IslemButon_Click;
            // 
            // button46
            // 
            button46.Location = new Point(3, 105);
            button46.Name = "button46";
            button46.Size = new Size(65, 28);
            button46.TabIndex = 15;
            button46.Text = "xⁿ";
            button46.UseVisualStyleBackColor = true;
            button46.Click += button46_Click;
            // 
            // button47
            // 
            button47.Location = new Point(74, 105);
            button47.Name = "button47";
            button47.Size = new Size(65, 28);
            button47.TabIndex = 16;
            button47.Text = "7";
            button47.UseVisualStyleBackColor = true;
            button47.Click += SayisalButon_Click;
            // 
            // button48
            // 
            button48.Location = new Point(145, 105);
            button48.Name = "button48";
            button48.Size = new Size(65, 28);
            button48.TabIndex = 17;
            button48.Text = "8";
            button48.UseVisualStyleBackColor = true;
            button48.Click += SayisalButon_Click;
            // 
            // button49
            // 
            button49.Location = new Point(216, 105);
            button49.Name = "button49";
            button49.Size = new Size(65, 28);
            button49.TabIndex = 18;
            button49.Text = "9";
            button49.UseVisualStyleBackColor = true;
            button49.Click += SayisalButon_Click;
            // 
            // button50
            // 
            button50.Location = new Point(287, 105);
            button50.Name = "button50";
            button50.Size = new Size(65, 28);
            button50.TabIndex = 19;
            button50.Text = "x";
            button50.UseVisualStyleBackColor = true;
            button50.Click += IslemButon_Click;
            // 
            // button51
            // 
            button51.Location = new Point(3, 139);
            button51.Name = "button51";
            button51.Size = new Size(65, 28);
            button51.TabIndex = 20;
            button51.Text = "10ⁿ";
            button51.UseVisualStyleBackColor = true;
            button51.Click += button51_Click;
            // 
            // button52
            // 
            button52.Location = new Point(74, 139);
            button52.Name = "button52";
            button52.Size = new Size(65, 28);
            button52.TabIndex = 21;
            button52.Text = "4";
            button52.UseVisualStyleBackColor = true;
            button52.Click += SayisalButon_Click;
            // 
            // button53
            // 
            button53.Location = new Point(145, 139);
            button53.Name = "button53";
            button53.Size = new Size(65, 28);
            button53.TabIndex = 22;
            button53.Text = "5";
            button53.UseVisualStyleBackColor = true;
            button53.Click += SayisalButon_Click;
            // 
            // button54
            // 
            button54.Location = new Point(216, 139);
            button54.Name = "button54";
            button54.Size = new Size(65, 28);
            button54.TabIndex = 23;
            button54.Text = "6";
            button54.UseVisualStyleBackColor = true;
            button54.Click += SayisalButon_Click;
            // 
            // button55
            // 
            button55.Location = new Point(287, 139);
            button55.Name = "button55";
            button55.Size = new Size(65, 28);
            button55.TabIndex = 24;
            button55.Text = "-";
            button55.UseVisualStyleBackColor = true;
            button55.Click += IslemButon_Click;
            // 
            // button56
            // 
            button56.Location = new Point(3, 173);
            button56.Name = "button56";
            button56.Size = new Size(65, 28);
            button56.TabIndex = 25;
            button56.Text = "log";
            button56.UseVisualStyleBackColor = true;
            button56.Click += BilimselIslem_Click;
            // 
            // button57
            // 
            button57.Location = new Point(74, 173);
            button57.Name = "button57";
            button57.Size = new Size(65, 28);
            button57.TabIndex = 26;
            button57.Text = "1";
            button57.UseVisualStyleBackColor = true;
            button57.Click += SayisalButon_Click;
            // 
            // button58
            // 
            button58.Location = new Point(145, 173);
            button58.Name = "button58";
            button58.Size = new Size(65, 28);
            button58.TabIndex = 27;
            button58.Text = "2";
            button58.UseVisualStyleBackColor = true;
            button58.Click += SayisalButon_Click;
            // 
            // button59
            // 
            button59.Location = new Point(216, 173);
            button59.Name = "button59";
            button59.Size = new Size(65, 28);
            button59.TabIndex = 28;
            button59.Text = "3";
            button59.UseVisualStyleBackColor = true;
            button59.Click += SayisalButon_Click;
            // 
            // button60
            // 
            button60.Location = new Point(3, 207);
            button60.Name = "button60";
            button60.Size = new Size(65, 28);
            button60.TabIndex = 30;
            button60.Text = "ln";
            button60.UseVisualStyleBackColor = true;
            button60.Click += BilimselIslem_Click;
            // 
            // button61
            // 
            button61.Location = new Point(74, 207);
            button61.Name = "button61";
            button61.Size = new Size(65, 28);
            button61.TabIndex = 31;
            button61.Text = "+/-";
            button61.UseVisualStyleBackColor = true;
            button61.Click += button27_Click;
            // 
            // button62
            // 
            button62.Location = new Point(145, 207);
            button62.Name = "button62";
            button62.Size = new Size(65, 28);
            button62.TabIndex = 32;
            button62.Text = "0";
            button62.UseVisualStyleBackColor = true;
            button62.Click += SayisalButon_Click;
            // 
            // button63
            // 
            button63.Location = new Point(216, 207);
            button63.Name = "button63";
            button63.Size = new Size(65, 28);
            button63.TabIndex = 33;
            button63.Text = ",";
            button63.UseVisualStyleBackColor = true;
            button63.Click += virgul_Click;
            // 
            // button64
            // 
            button64.BackColor = Color.RoyalBlue;
            button64.Font = new Font("Segoe UI", 14.25F);
            button64.ForeColor = SystemColors.Window;
            button64.Location = new Point(287, 207);
            button64.Name = "button64";
            button64.Size = new Size(65, 28);
            button64.TabIndex = 34;
            button64.Text = "=";
            button64.UseVisualStyleBackColor = false;
            button64.Click += Esittir_Click;
            // 
            // button65
            // 
            button65.Location = new Point(287, 173);
            button65.Name = "button65";
            button65.Size = new Size(65, 28);
            button65.TabIndex = 29;
            button65.Text = "+";
            button65.UseVisualStyleBackColor = true;
            button65.Click += IslemButon_Click;
            // 
            // PanelGrafik
            // 
            PanelGrafik.Location = new Point(4, 265);
            PanelGrafik.Name = "PanelGrafik";
            PanelGrafik.Size = new Size(355, 241);
            PanelGrafik.TabIndex = 34;
            PanelGrafik.Visible = false;
            PanelGrafik.Paint += PanelGrafik_Paint;
            // 
            // panelTarih
            // 
            panelTarih.Controls.Add(textBox1);
            panelTarih.Controls.Add(dateTimePicker2);
            panelTarih.Controls.Add(dateTimePicker1);
            panelTarih.Controls.Add(label3);
            panelTarih.Controls.Add(label2);
            panelTarih.Controls.Add(label1);
            panelTarih.Location = new Point(4, 60);
            panelTarih.Name = "panelTarih";
            panelTarih.Size = new Size(356, 446);
            panelTarih.TabIndex = 35;
            panelTarih.Visible = false;
            panelTarih.Paint += panelTarih_Paint;
            // 
            // textBox1
            // 
            textBox1.Location = new Point(0, 255);
            textBox1.Name = "textBox1";
            textBox1.Size = new Size(200, 23);
            textBox1.TabIndex = 28;
            // 
            // dateTimePicker2
            // 
            dateTimePicker2.Location = new Point(0, 176);
            dateTimePicker2.Name = "dateTimePicker2";
            dateTimePicker2.Size = new Size(200, 23);
            dateTimePicker2.TabIndex = 30;
            // 
            // dateTimePicker1
            // 
            dateTimePicker1.Location = new Point(1, 81);
            dateTimePicker1.Name = "dateTimePicker1";
            dateTimePicker1.Size = new Size(200, 23);
            dateTimePicker1.TabIndex = 29;
            // 
            // label3
            // 
            label3.AutoSize = true;
            label3.Location = new Point(4, 225);
            label3.Name = "label3";
            label3.Size = new Size(29, 15);
            label3.TabIndex = 28;
            label3.Text = "Fark";
            // 
            // label2
            // 
            label2.AutoSize = true;
            label2.Location = new Point(4, 142);
            label2.Name = "label2";
            label2.Size = new Size(65, 15);
            label2.TabIndex = 1;
            label2.Text = "Şu Tarihte :";
            // 
            // label1
            // 
            label1.AutoSize = true;
            label1.Location = new Point(4, 48);
            label1.Name = "label1";
            label1.Size = new Size(72, 15);
            label1.TabIndex = 0;
            label1.Text = "Şu Tarihten :";
            // 
            // Form1
            // 
            AutoScaleDimensions = new SizeF(7F, 15F);
            AutoScaleMode = AutoScaleMode.Font;
            ClientSize = new Size(367, 523);
            Controls.Add(panelTarih);
            Controls.Add(PanelGrafik);
            Controls.Add(PanelBilimsel);
            Controls.Add(panel1);
            Controls.Add(button1);
            Controls.Add(PanelProgramlayici);
            Controls.Add(PanelStandart);
            Controls.Add(txtText);
            Icon = (Icon)resources.GetObject("$this.Icon");
            Name = "Form1";
            Text = "Hesap Makinesi";
            PanelStandart.ResumeLayout(false);
            PanelProgramlayici.ResumeLayout(false);
            panel1.ResumeLayout(false);
            PanelBilimsel.ResumeLayout(false);
            panelTarih.ResumeLayout(false);
            panelTarih.PerformLayout();
            ResumeLayout(false);
        }

        #endregion

        private RichTextBox txtText;
        private TableLayoutPanel PanelStandart;
        private Button button7;
        private Button button8;
        private Button button9;
        private Button button10;
        private Button button11;
        private Button button12;
        private Button button13;
        private Button button14;
        private Button button15;
        private Button button16;
        private Button button17;
        private Button button18;
        private Button button19;
        private Button button20;
        private Button button21;
        private Button button22;
        private Button button23;
        private Button button24;
        private Button button25;
        private Button button26;
        private Button button27;
        private Button button28;
        private Button button29;
        private Button button30;
        private TableLayoutPanel PanelProgramlayici;
        private Button button31;
        private Button button68;
        private Button button67;
        private Button button66;
        private Button button71;
        private Button button72;
        private Button button70;
        private Button button69;
        private Button button79;
        private Button button80;
        private Button button78;
        private Button button77;
        private Button button75;
        private Button button76;
        private Button button73;
        private Button button74;
        private Button button81;
        private Button button82;
        private Button button86;
        private Button button85;
        private Button button84;
        private Button button83;
        private Button button1;
        private Panel panel1;
        private Button button6;
        private Button button5;
        private Button button4;
        private Button button3;
        private Button button2;
        private TableLayoutPanel PanelBilimsel;
        private Button button32;
        private Button button33;
        private Button button34;
        private Button button35;
        private Button button36;
        private Button button37;
        private Button button38;
        private Button button39;
        private Button button40;
        private Button button41;
        private Button button42;
        private Button button43;
        private Button button44;
        private Button button45;
        private Button button46;
        private Button button47;
        private Button button48;
        private Button button49;
        private Button button50;
        private Button button51;
        private Button button52;
        private Button button53;
        private Button button54;
        private Button button55;
        private Button button56;
        private Button button57;
        private Button button58;
        private Button button59;
        private Button button60;
        private Button button61;
        private Button button62;
        private Button button63;
        private Button button64;
        private Button button65;
        private Panel PanelGrafik;
        private Panel panelTarih;
        private TextBox textBox1;
        private DateTimePicker dateTimePicker2;
        private DateTimePicker dateTimePicker1;
        private Label label3;
        private Label label2;
        private Label label1;
        private ComboBox comboFormat;
    }
}
